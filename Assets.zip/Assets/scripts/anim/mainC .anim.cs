using UnityEngine;

// Ana karakterin animasyonlarini surer. Animator parametreleri:
//   moving (bool)  -> run
//   jump   (bool)  -> jump   (frame'i y hizina gore dondurulur)
//   dash   (bool)  -> dash
//   attack (trigger) -> attack
// Idle state'i "New Animation" (varsayilan) olarak birakildi.
[RequireComponent(typeof(Animator))]
public class mainCanim : MonoBehaviour
{
    [Header("Referanslar")]
    [SerializeField] private Animator animator;
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private playermovement movement;

    [Header("Ziplama frame dondurma")]
    [Tooltip("Yukari cikis hizi: bu ve ustunde animasyon ilk frame'de (t=0) kalir.")]
    [SerializeField] private float riseVelocity = 20f;
    [Tooltip("Dusus hizi: bu ve altinda animasyon son frame'de (t=1) kalir. Apeks (hiz ~0) ortadaki frame.")]
    [SerializeField] private float fallVelocity = -20f;

    [Tooltip("Bu esigin uzerindeki yatay girdi 'moving' (run) sayilir.")]
    [SerializeField] private float moveThreshold = 0.01f;

    [Header("DEBUG (sorun cozulunce kapat)")]
    [Tooltip("Ekranda grounded / vy / state degerlerini gosterir.")]
    [SerializeField] private bool debugOverlay = true;

    // Son okunan degerler (debug icin).
    private bool dbgGrounded, dbgDashing;
    private float dbgVy, dbgHorizontal;
    private bool dbgPrevGrounded = true;

    // Parametre / state hash'leri
    private static readonly int MovingHash = Animator.StringToHash("moving");
    private static readonly int JumpHash = Animator.StringToHash("jump");
    private static readonly int DashHash = Animator.StringToHash("dash");
    private static readonly int AttackHash = Animator.StringToHash("attack");
    private static readonly int JumpStateHash = Animator.StringToHash("jump");

    // Editor'de bilesen eklendiginde referanslari otomatik doldur.
    private void Reset()
    {
        ResolveReferences();
    }

    // Oyun basladiginda referanslar Inspector'da bos kalmis olsa bile doldur.
    // (Reset yalnizca editorde, bilesen eklenirken calisir; runtime'da calismaz.)
    private void Awake()
    {
        ResolveReferences();

        if (movement == null)
            Debug.LogWarning("mainCanim: 'movement' referansi bulunamadi. " +
                "jump/run animasyonlari calismaz; playermovement ile ayni objede olmali veya elle atanmali.", this);
    }

    private void ResolveReferences()
    {
        if (animator == null) animator = GetComponent<Animator>();
        if (rb == null) rb = GetComponentInParent<Rigidbody2D>();
        if (movement == null) movement = GetComponentInParent<playermovement>();
    }

    private void Update()
    {
        if (animator == null) return;

        // movement yoksa jump'a kilitlenmemek icin 'yerde' kabul et.
        bool grounded = movement == null || movement.IsGrounded;
        bool dashing = movement != null && movement.IsDashing;
        float horizontal = Input.GetAxisRaw("Horizontal");

        dbgGrounded = grounded;
        dbgDashing = dashing;
        dbgVy = rb != null ? rb.linearVelocity.y : 0f;
        dbgHorizontal = horizontal;

        // Console'a (kamera bug'indan bagimsiz) grounded degisimini yaz.
        if (debugOverlay && grounded != dbgPrevGrounded)
        {
            Debug.Log($"[anim] grounded -> {grounded} | movementRef={(movement != null ? "OK" : "NULL")} | vy={dbgVy:0.00}", this);
            dbgPrevGrounded = grounded;
        }

        // run: yerdeyken ve yatay girdi varken (dash sirasinda degil)
        animator.SetBool(MovingHash, grounded && !dashing && Mathf.Abs(horizontal) > moveThreshold);

        // jump: havadayken (dash sirasinda degil)
        animator.SetBool(JumpHash, !grounded && !dashing);

        // dash (Shift)
        animator.SetBool(DashHash, dashing);

        // attack (sol tik)
        if (Input.GetMouseButtonDown(0))
            animator.SetTrigger(AttackHash);
    }

    // Ziplama state'indeyken frame'i y hizina gore sabitle.
    private void LateUpdate()
    {
        if (animator == null || rb == null) return;

        // Yerdeyken dondurma yapma: aksi halde normalizedTime sabitlenir ve
        // jump -> idle gecisi hic tetiklenmez (jump'a kilitlenir).
        bool grounded = movement == null || movement.IsGrounded;
        if (grounded) return;

        // Sadece tam jump state'indeyken ve gecis (transition) yokken mudahale et;
        // boylece jump'a giris/cikis gecisleri bozulmaz.
        if (animator.IsInTransition(0)) return;

        AnimatorStateInfo state = animator.GetCurrentAnimatorStateInfo(0);
        if (state.shortNameHash != JumpStateHash) return;

        // hiz -> normalizedTime: riseVelocity -> 0 (ilk frame),
        // 0 civari -> ~0.5 (ortadaki frame), fallVelocity -> 1 (son frame).
        float t = Mathf.InverseLerp(riseVelocity, fallVelocity, rb.linearVelocity.y);

        // Her frame istenen zamana geri sarilarak animasyon o frame'de "donmus" gorunur.
        animator.Play(JumpStateHash, 0, t);
    }

    private void OnGUI()
    {
        if (!debugOverlay || animator == null) return;

        string stateName = "-";
        AnimatorStateInfo s = animator.GetCurrentAnimatorStateInfo(0);
        if (s.IsName("jump")) stateName = "jump";
        else if (s.IsName("run")) stateName = "run";
        else if (s.IsName("dash")) stateName = "dash";
        else if (s.IsName("attack")) stateName = "attack";
        else if (s.IsName("New Animation")) stateName = "idle (New Animation)";

        GUI.color = Color.black;
        var style = new GUIStyle { fontSize = 22, normal = { textColor = Color.white } };
        string text =
            $"movement ref : {(movement != null ? "OK" : "NULL")}\n" +
            $"grounded     : {dbgGrounded}\n" +
            $"dashing      : {dbgDashing}\n" +
            $"vy           : {dbgVy:0.00}\n" +
            $"horizontal   : {dbgHorizontal:0.00}\n" +
            $"jump param   : {animator.GetBool(JumpHash)}\n" +
            $"moving param : {animator.GetBool(MovingHash)}\n" +
            $"STATE        : {stateName}";
        GUI.Box(new Rect(8, 8, 320, 210), "");
        GUI.Label(new Rect(16, 12, 320, 210), text, style);
    }
}
